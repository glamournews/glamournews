//third_party/javascript/css_element_queries/dist/ResizeSensor.min.js
/**
 * @description Polyfill for element based media-queries.
 * @version 1.2.1
 * @author Marc J. Schmidt
 * @url http://marcj.github.io/css-element-queries/
 * @license
 * Copyright (c) 2013 Marc J. Schmidt
 *
 * Use of this source code is governed by a MIT-style
 * license that can be found in the LICENSE file or at
 * https://opensource.org/licenses/MIT.
 */
var $jscomp = $jscomp || {};
$jscomp.scope = {};
$jscomp.ASSUME_ES5 = !1;
$jscomp.ASSUME_NO_NATIVE_MAP = !1;
$jscomp.ASSUME_NO_NATIVE_SET = !1;
$jscomp.SIMPLE_FROUND_POLYFILL = !1;
$jscomp.ISOLATE_POLYFILLS = !1;
$jscomp.FORCE_POLYFILL_PROMISE = !1;
$jscomp.FORCE_POLYFILL_PROMISE_WHEN_NO_UNHANDLED_REJECTION = !1;
$jscomp.defineProperty = $jscomp.ASSUME_ES5 || "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
    if (a == Array.prototype || a == Object.prototype) return a;
    a[b] = c.value;
    return a
};
$jscomp.getGlobal = function(a) {
    a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
    for (var b = 0; b < a.length; ++b) {
        var c = a[b];
        if (c && c.Math == Math) return c
    }
    throw Error("Cannot find global object");
};
$jscomp.global = $jscomp.getGlobal(this);
$jscomp.IS_SYMBOL_NATIVE = "function" === typeof Symbol && "symbol" === typeof Symbol("x");
$jscomp.TRUST_ES6_POLYFILLS = !$jscomp.ISOLATE_POLYFILLS || $jscomp.IS_SYMBOL_NATIVE;
$jscomp.polyfills = {};
$jscomp.propertyToPolyfillSymbol = {};
$jscomp.POLYFILL_PREFIX = "$jscp$";
var $jscomp$lookupPolyfilledValue = function(a, b) {
    var c = $jscomp.propertyToPolyfillSymbol[b];
    if (null == c) return a[b];
    c = a[c];
    return void 0 !== c ? c : a[b]
};
$jscomp.polyfill = function(a, b, c, d) {
    b && ($jscomp.ISOLATE_POLYFILLS ? $jscomp.polyfillIsolated(a, b, c, d) : $jscomp.polyfillUnisolated(a, b, c, d))
};
$jscomp.polyfillUnisolated = function(a, b, c, d) {
    c = $jscomp.global;
    a = a.split(".");
    for (d = 0; d < a.length - 1; d++) {
        var g = a[d];
        if (!(g in c)) return;
        c = c[g]
    }
    a = a[a.length - 1];
    d = c[a];
    b = b(d);
    b != d && null != b && $jscomp.defineProperty(c, a, {
        configurable: !0,
        writable: !0,
        value: b
    })
};
$jscomp.polyfillIsolated = function(a, b, c, d) {
    var g = a.split(".");
    a = 1 === g.length;
    d = g[0];
    d = !a && d in $jscomp.polyfills ? $jscomp.polyfills : $jscomp.global;
    for (var n = 0; n < g.length - 1; n++) {
        var r = g[n];
        if (!(r in d)) return;
        d = d[r]
    }
    g = g[g.length - 1];
    c = $jscomp.IS_SYMBOL_NATIVE && "es6" === c ? d[g] : null;
    b = b(c);
    null != b && (a ? $jscomp.defineProperty($jscomp.polyfills, g, {
        configurable: !0,
        writable: !0,
        value: b
    }) : b !== c && (void 0 === $jscomp.propertyToPolyfillSymbol[g] && (c = 1E9 * Math.random() >>> 0, $jscomp.propertyToPolyfillSymbol[g] = $jscomp.IS_SYMBOL_NATIVE ?
        $jscomp.global.Symbol(g) : $jscomp.POLYFILL_PREFIX + c + "$" + g), $jscomp.defineProperty(d, $jscomp.propertyToPolyfillSymbol[g], {
        configurable: !0,
        writable: !0,
        value: b
    })))
};
$jscomp.polyfill("globalThis", function(a) {
    return a || $jscomp.global
}, "es_2020", "es3");
$jscomp.arrayIteratorImpl = function(a) {
    var b = 0;
    return function() {
        return b < a.length ? {
            done: !1,
            value: a[b++]
        } : {
            done: !0
        }
    }
};
$jscomp.arrayIterator = function(a) {
    return {
        next: $jscomp.arrayIteratorImpl(a)
    }
};
$jscomp.initSymbol = function() {};
$jscomp.polyfill("Symbol", function(a) {
    if (a) return a;
    var b = function(n, r) {
        this.$jscomp$symbol$id_ = n;
        $jscomp.defineProperty(this, "description", {
            configurable: !0,
            writable: !0,
            value: r
        })
    };
    b.prototype.toString = function() {
        return this.$jscomp$symbol$id_
    };
    var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
        d = 0,
        g = function(n) {
            if (this instanceof g) throw new TypeError("Symbol is not a constructor");
            return new b(c + (n || "") + "_" + d++, n)
        };
    return g
}, "es6", "es3");
$jscomp.polyfill("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = $jscomp.global[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && $jscomp.defineProperty(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return $jscomp.iteratorPrototype($jscomp.arrayIteratorImpl(this))
                }
            })
        }
        return a
    }, "es6",
    "es3");
$jscomp.iteratorPrototype = function(a) {
    a = {
        next: a
    };
    a[Symbol.iterator] = function() {
        return this
    };
    return a
};
$jscomp.iteratorFromArray = function(a, b) {
    a instanceof String && (a += "");
    var c = 0,
        d = !1,
        g = {
            next: function() {
                if (!d && c < a.length) {
                    var n = c++;
                    return {
                        value: b(n, a[n]),
                        done: !1
                    }
                }
                d = !0;
                return {
                    done: !0,
                    value: void 0
                }
            }
        };
    g[Symbol.iterator] = function() {
        return g
    };
    return g
};
$jscomp.polyfill("Array.prototype.keys", function(a) {
    return a ? a : function() {
        return $jscomp.iteratorFromArray(this, function(b) {
            return b
        })
    }
}, "es6", "es3");
(function(a, b) {
    "function" === typeof define && define.amd ? define(b) : "object" === typeof exports ? module.exports = b() : a.ResizeSensor = b()
})("undefined" !== typeof window ? window : this, function() {
    function a(f, l) {
        var h = Object.prototype.toString.call(f),
            t = 0,
            q = f.length;
        if ("[object Array]" === h || "[object NodeList]" === h || "[object HTMLCollection]" === h || "[object Object]" === h || "undefined" !== typeof jQuery && f instanceof jQuery || "undefined" !== typeof Elements && f instanceof Elements)
            for (; t < q; t++) l(f[t]);
        else l(f)
    }

    function b(f) {
        if (!f.getBoundingClientRect) return {
            width: f.offsetWidth,
            height: f.offsetHeight
        };
        f = f.getBoundingClientRect();
        return {
            width: Math.round(f.width),
            height: Math.round(f.height)
        }
    }

    function c(f, l) {
        Object.keys(l).forEach(function(h) {
            f.style[h] = l[h]
        })
    }
    if ("undefined" === typeof window) return null;
    var d = "undefined" != typeof window && Math == Math ? window : "undefined" != typeof self && self.Math == Math ? self : globalThis,
        g = d.requestAnimationFrame || d.mozRequestAnimationFrame || d.webkitRequestAnimationFrame || function(f) {
            return d.setTimeout(f, 20)
        },
        n = d.cancelAnimationFrame || d.mozCancelAnimationFrame ||
        d.webkitCancelAnimationFrame || function(f) {
            d.clearTimeout(f)
        },
        r = function(f, l) {
            function h() {
                var e = [];
                this.add = function(p) {
                    e.push(p)
                };
                var k, m;
                this.call = function(p) {
                    k = 0;
                    for (m = e.length; k < m; k++) e[k].call(this, p)
                };
                this.remove = function(p) {
                    var u = [];
                    k = 0;
                    for (m = e.length; k < m; k++) e[k] !== p && u.push(e[k]);
                    e = u
                };
                this.length = function() {
                    return e.length
                }
            }

            function t(e, k) {
                if (e)
                    if (e.resizedAttached) e.resizedAttached.add(k);
                    else {
                        e.resizedAttached = new h;
                        e.resizedAttached.add(k);
                        e.resizeSensor = document.createElement("div");
                        e.resizeSensor.dir = "ltr";
                        e.resizeSensor.className = "resize-sensor";
                        var m = {
                            pointerEvents: "none",
                            position: "absolute",
                            left: "0px",
                            top: "0px",
                            right: "0px",
                            bottom: "0px",
                            overflow: "hidden",
                            zIndex: "-1",
                            visibility: "hidden",
                            maxWidth: "100%"
                        };
                        k = {
                            position: "absolute",
                            left: "0px",
                            top: "0px",
                            transition: "0s"
                        };
                        c(e.resizeSensor, m);
                        var p = document.createElement("div");
                        p.className = "resize-sensor-expand";
                        c(p, m);
                        var u = document.createElement("div");
                        c(u, k);
                        p.appendChild(u);
                        var v = document.createElement("div");
                        v.className = "resize-sensor-shrink";
                        c(v, m);
                        m = document.createElement("div");
                        c(m, k);
                        c(m, {
                            width: "200%",
                            height: "200%"
                        });
                        v.appendChild(m);
                        e.resizeSensor.appendChild(p);
                        e.resizeSensor.appendChild(v);
                        e.appendChild(e.resizeSensor);
                        k = (k = window.getComputedStyle(e)) ? k.getPropertyValue("position") : null;
                        "absolute" !== k && "relative" !== k && "fixed" !== k && "sticky" !== k && (e.style.position = "relative");
                        var B = !1,
                            A = 0,
                            x = b(e),
                            C = 0,
                            D = 0,
                            E = !0;
                        q = 0;
                        var G = function() {
                                var w = e.offsetWidth,
                                    y = e.offsetHeight;
                                u.style.width = w + 10 + "px";
                                u.style.height = y + 10 + "px";
                                p.scrollLeft = w + 10;
                                p.scrollTop = y + 10;
                                v.scrollLeft = w + 10;
                                v.scrollTop = y + 10
                            },
                            z = function() {
                                if (E) {
                                    if (0 === e.offsetWidth && 0 === e.offsetHeight) {
                                        q || (q = g(function() {
                                            q = 0;
                                            z()
                                        }));
                                        return
                                    }
                                    E = !1
                                }
                                G()
                            };
                        e.resizeSensor.resetSensor = z;
                        var H = function() {
                            A = 0;
                            B && (C = x.width, D = x.height, e.resizedAttached && e.resizedAttached.call(x))
                        };
                        k = function() {
                            x = b(e);
                            (B = x.width !== C || x.height !== D) && !A && (A = g(H));
                            z()
                        };
                        m = function(w, y, F) {
                            w.attachEvent ? w.attachEvent("on" + y, F) : w.addEventListener(y, F)
                        };
                        m(p, "scroll", k);
                        m(v, "scroll", k);
                        q = g(function() {
                            q = 0;
                            z()
                        })
                    }
            }
            var q = 0;
            a(f,
                function(e) {
                    t(e, l)
                });
            this.detach = function(e) {
                q && (n(q), q = 0);
                r.detach(f, e)
            };
            this.reset = function() {
                f.resizeSensor.resetSensor && f.resizeSensor.resetSensor()
            }
        };
    r.reset = function(f) {
        a(f, function(l) {
            f.resizeSensor.resetSensor && l.resizeSensor.resetSensor()
        })
    };
    r.detach = function(f, l) {
        a(f, function(h) {
            if (h) {
                if (h.resizedAttached && "function" === typeof l && (h.resizedAttached.remove(l), h.resizedAttached.length())) return;
                h.resizeSensor && (h.contains(h.resizeSensor) && h.removeChild(h.resizeSensor), delete h.resizeSensor,
                    delete h.resizedAttached)
            }
        })
    };
    if ("undefined" !== typeof MutationObserver) {
        var I = new MutationObserver(function(f) {
            for (var l in f)
                if (f.hasOwnProperty(l))
                    for (var h = f[l].addedNodes, t = 0; t < h.length; t++) h[t].resizeSensor && r.reset(h[t])
        });
        document.addEventListener("DOMContentLoaded", function(f) {
            I.observe(document.body, {
                childList: !0,
                subtree: !0
            })
        })
    }
    return r
});

//third_party/javascript/css_element_queries/dist/ElementQueries.min.js
/**
 * @description Polyfill for element based media-queries.
 * @version 1.0.2
 * @author Marc J. Schmidt
 * @url http://marcj.github.io/css-element-queries/
 * @license
 * Copyright (c) 2013 Marc J. Schmidt
 *
 * Use of this source code is governed by a MIT-style
 * license that can be found in the LICENSE file or at
 * https://opensource.org/licenses/MIT.
 */
(function(k, c) {
    "function" === typeof define && define.amd ? define(["./ResizeSensor.js"], c) : "object" === typeof exports ? module.exports = c(require("./ResizeSensor.js")) : (k.ElementQueries = c(k.ResizeSensor), k.ElementQueries.listen())
})("undefined" !== typeof window ? window : this, function(k) {
    var c = function() {
        function c(a) {
            a || (a = document.documentElement);
            a = window.getComputedStyle(a, null).fontSize;
            return parseFloat(a) || 16
        }

        function t(a, b) {
            var d = b.split(/\d/);
            d = d[d.length - 1];
            b = parseFloat(b);
            switch (d) {
                case "px":
                    return b;
                case "em":
                    return b * c(a);
                case "rem":
                    return b * c();
                case "vw":
                    return b * document.documentElement.clientWidth / 100;
                case "vh":
                    return b * document.documentElement.clientHeight / 100;
                case "vmin":
                case "vmax":
                    return b * (0, Math["vmin" === d ? "min" : "max"])(document.documentElement.clientWidth / 100, document.documentElement.clientHeight / 100);
                default:
                    return b
            }
        }

        function x(a, b) {
            var d, l;
            this.element = a;
            var h, c, g, e, f, n, p, q = ["min-width", "min-height", "max-width", "max-height"];
            this.call = function() {
                var a = this.element;
                a.getBoundingClientRect ?
                    (a = a.getBoundingClientRect(), d = Math.round(a.width), l = Math.round(a.height)) : (d = a.offsetWidth, l = a.offsetHeight);
                f = {};
                for (h in m[b]) m[b].hasOwnProperty(h) && (c = m[b][h], g = t(this.element, c.value), e = "width" === c.property ? d : l, p = c.mode + "-" + c.property, n = "", "min" === c.mode && e >= g && (n += c.value), "max" === c.mode && e <= g && (n += c.value), f[p] || (f[p] = ""), n && -1 === (" " + f[p] + " ").indexOf(" " + n + " ") && (f[p] += " " + n));
                for (var r in q) q.hasOwnProperty(r) && (f[q[r]] ? this.element.setAttribute(q[r], f[q[r]].substr(1)) : this.element.removeAttribute(q[r]))
            }
        }

        function y(a, b) {
            a.elementQueriesSetupInformation || (a.elementQueriesSetupInformation = new x(a, b));
            a.elementQueriesSensor || (a.elementQueriesSensor = new k(a, function() {
                a.elementQueriesSetupInformation.call()
            }));
            a.elementQueriesSetupInformation.call()
        }

        function z(a) {
            var b;
            document.querySelectorAll && (b = a ? a.querySelectorAll.bind(a) : document.querySelectorAll.bind(document));
            b || "undefined" === typeof $$ || (b = $$);
            b || "undefined" === typeof jQuery || (b = jQuery);
            if (!b) throw "No document.querySelectorAll, jQuery or Mootools's $$ found.";
            return b
        }

        function B(a) {
            function b() {
                var b = !1;
                for (l in d) d.hasOwnProperty(l) && c[l].minWidth && a.offsetWidth > c[l].minWidth && (b = l);
                b || (b = g);
                if (e !== b)
                    if (m[b]) d[e].style.display = "none", d[b].style.display = "block", e = b;
                    else {
                        var l = new Image;
                        l.onload = function() {
                            d[b].src = h[b];
                            d[e].style.display = "none";
                            d[b].style.display = "block";
                            m[b] = !0;
                            e = b
                        };
                        l.src = h[b]
                    }
                else d[b].src = h[b]
            }
            var d = [],
                c = [],
                h = [],
                g = 0,
                e = -1,
                m = [],
                f;
            for (f in a.children)
                if (a.children.hasOwnProperty(f) && a.children[f].tagName && "img" === a.children[f].tagName.toLowerCase()) {
                    d.push(a.children[f]);
                    var n = a.children[f].getAttribute("min-width") || a.children[f].getAttribute("data-min-width"),
                        p = a.children[f].getAttribute("data-src") || a.children[f].getAttribute("url");
                    h.push(p);
                    c.push({
                        minWidth: n
                    });
                    n ? a.children[f].style.display = "none" : (g = d.length - 1, a.children[f].style.display = "block")
                }
            e = g;
            a.resizeSensor = new k(a, b);
            b()
        }

        function C() {
            for (var a = z()("[data-responsive-image],[responsive-image]"), b = 0, d = a.length; b < d; b++) B(a[b])
        }

        function u(a) {
            var b, d;
            for (a = a.replace(/'/g, '"'); null !== (b = D.exec(a));) {
                var c =
                    b[1] + b[3];
                for (b = b[2]; null !== (d = E.exec(b));) {
                    var h = c,
                        g = d[1],
                        k = d[2];
                    d = d[3];
                    if ("undefined" === typeof m[h]) {
                        m[h] = [];
                        var t = v.length;
                        e.textContent += "\n" + h + " {animation: 0.1s element-queries;}";
                        e.textContent += "\n" + h + " > .resize-sensor {min-width: " + t + "px;}";
                        v.push(h)
                    }
                    m[h].push({
                        mode: g,
                        property: k,
                        value: d
                    })
                }
            }
        }

        function w(a) {
            if (a)
                if ("string" === typeof a) a = a.toLowerCase(), -1 === a.indexOf("min-width") && -1 === a.indexOf("max-width") || u(a);
                else
                    for (var b = 0, d = a.length; b < d; b++)
                        if (1 === a[b].type) {
                            var c = a[b].selectorText || a[b].cssText; -
                            1 !== c.indexOf("min-height") || -1 !== c.indexOf("max-height") ? u(c) : (-1 !== c.indexOf("min-width") || -1 !== c.indexOf("max-width")) && u(c)
                        } else 4 === a[b].type ? w(a[b].cssRules || a[b].rules) : 3 === a[b].type && a[b].styleSheet.hasOwnProperty("cssRules") && w(a[b].styleSheet.cssRules)
        }
        var e, m = {},
            v = [],
            D = /,?[\s\t]*([^,\n]*?)((?:\[[\s\t]*?(?:min|max)-(?:width|height)[\s\t]*?[~$\^]?=[\s\t]*?"[^"]*?"[\s\t]*?])+)([^,\n\s\{]*)/mgi,
            E = /\[[\s\t]*?(min|max)-(width|height)[\s\t]*?[~$\^]?=[\s\t]*?"([^"]*?)"[\s\t]*?]/mgi,
            A = !1;
        this.init =
            function() {
                var a = "animationstart";
                "undefined" !== typeof document.documentElement.style.webkitAnimationName ? a = "webkitAnimationStart" : "undefined" !== typeof document.documentElement.style.MozAnimationName ? a = "mozanimationstart" : "undefined" !== typeof document.documentElement.style.OAnimationName && (a = "oanimationstart");
                document.body.addEventListener(a, function(a) {
                    var b = a.target;
                    if (-1 !== window.getComputedStyle(b, null).getPropertyValue("animation-name").indexOf("element-queries")) {
                        b.elementQueriesSensor = new k(b,
                            function() {
                                b.elementQueriesSetupInformation && b.elementQueriesSetupInformation.call()
                            });
                        var c = window.getComputedStyle(b.resizeSensor, null).getPropertyValue("min-width");
                        c = parseInt(c.replace("px", ""));
                        y(a.target, v[c])
                    }
                });
                A || (e = document.createElement("style"), e.type = "text/css", e.textContent = "[responsive-image] > img, [data-responsive-image] {overflow: hidden; padding: 0; } [responsive-image] > img, [data-responsive-image] > img {width: 100%;}", e.textContent += "\n@keyframes element-queries { 0% { visibility: inherit; } }",
                    document.getElementsByTagName("head")[0].appendChild(e), A = !0);
                a = 0;
                for (var b = document.styleSheets.length; a < b; a++) try {
                    document.styleSheets[a].href && 0 === document.styleSheets[a].href.indexOf("file://") && console.log("CssElementQueries: unable to parse local css files, " + document.styleSheets[a].href), w(document.styleSheets[a].cssRules || document.styleSheets[a].rules || document.styleSheets[a].cssText)
                } catch (d) {}
                C()
            };
        this.findElementQueriesElements = function(a) {
            var b = z(a),
                c;
            for (c in m)
                if (m.hasOwnProperty(c))
                    for (var g =
                            b(c, a), e = 0, k = g.length; e < k; e++) y(g[e], c)
        };
        this.update = function() {
            this.init()
        }
    };
    c.update = function() {
        c.instance.update()
    };
    c.detach = function(c) {
        c.elementQueriesSetupInformation ? (c.elementQueriesSensor.detach(), delete c.elementQueriesSetupInformation, delete c.elementQueriesSensor) : c.resizeSensor && (c.resizeSensor.detach(), delete c.resizeSensor)
    };
    c.init = function() {
        c.instance || (c.instance = new c);
        c.instance.init()
    };
    var x = function(c) {
        if (document.addEventListener) document.addEventListener("DOMContentLoaded",
            c, !1);
        else if (/KHTML|WebKit|iCab/i.test(navigator.userAgent)) var g = setInterval(function() {
            /loaded|complete/i.test(document.readyState) && (c(), clearInterval(g))
        }, 10);
        else window.onload = c
    };
    c.findElementQueriesElements = function(g) {
        c.instance.findElementQueriesElements(g)
    };
    c.listen = function() {
        x(c.init)
    };
    return c
});